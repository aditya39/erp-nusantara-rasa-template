"""
Agent: penghubung antara pertanyaan user, model, dan tools.

jalankan() adalah generator yang mengeluarkan event, supaya layar bisa menampilkan
setiap langkah secara langsung. Bentuk event adalah KONTRAK dengan layar (web/static/app.js)
dan dengan tes penerimaan, jadi nama field-nya jangan diubah:

  {"tipe": "mulai",    "mode", "model", "pengguna"}
  {"tipe": "berpikir", "langkah"}                      model sedang diminta memutuskan
  {"tipe": "tool",     "langkah", "nama", "argumen", "status", "ringkas", "durasi_ms", "hasil",
                       "query" (opsional)}             status: ok / ditolak / error / diminta
  {"tipe": "grafik",   "grafik"}                       data grafik dari hasil tool (tidak dikirim ke model)
  {"tipe": "draft_so", "draft"}                        draft sales order (BELUM disimpan)
  {"tipe": "jawaban",  "teks"}                         jawaban akhir
  {"tipe": "error",    "pesan"}                        kegagalan (mis. model tidak dapat dihubungi)
  {"tipe": "selesai",  "durasi_ms", "token_masuk", "token_keluar"}   selalu event terakhir
"""
from __future__ import annotations

import time
from typing import Any, Iterator

import openai
import psycopg

from . import config, db, llm, pengguna, prompt, tools


def _pesan_error(e: Exception, mode: str, cfg: config.ModelConfig) -> str:
    if isinstance(e, openai.APITimeoutError):
        return (f"Model {mode} tidak menjawab dalam {config.MODEL_TIMEOUT:g} detik. "
                "Server model kemungkinan sedang sibuk; coba lagi sebentar lagi.")
    if isinstance(e, openai.APIConnectionError):
        return (f"Model {mode} tidak dapat dihubungi di {cfg.base_url}. "
                "Periksa LOKAL_BASE_URL di .env (server workshop) atau koneksi internet (cloud).")
    if isinstance(e, psycopg.OperationalError):
        return f"Database tidak dapat dihubungi: {str(e).splitlines()[0]}"
    return f"Model {mode} mengembalikan error: {e}"


_GAGAL = (openai.APIError, RuntimeError, psycopg.OperationalError)


def eksekusi_tool(nama: str, argumen: dict, kode_pengguna: str,
                  daftar_query: list[dict] | None = None) -> tuple[dict, str]:
    """
    Jalankan satu tool atas nama user. Kembalikan (hasil, status): ok / ditolak / error.
    Bila daftar_query diberikan, SQL yang dijalankan tool ditambahkan ke list itu (untuk layar).
    """
    t = tools.REGISTRY.get(nama)
    if t is None:
        return {"error": f"Tool '{nama}' tidak tersedia."}, "error"
    # Pengaman utama: izin dicek oleh KODE sebelum query apa pun, bukan diserahkan ke prompt.
    if not pengguna.punya_izin(kode_pengguna, t.izin):
        return {"error": "AKSES_DITOLAK",
                "pesan": f"User tidak memiliki izin '{pengguna.NAMA_IZIN.get(t.izin, t.izin)}'."}, "ditolak"
    with db.catat_query() as dicatat:
        try:
            hasil, status = t.fungsi(**tools.rapikan_argumen(t.parameter, argumen)), "ok"
        except TypeError as e:
            hasil, status = {"error": f"Argumen tidak valid: {e}"}, "error"
        except psycopg.Error as e:
            hasil, status = {"error": "Query database gagal.", "detail": str(e).splitlines()[0]}, "error"
    if daftar_query is not None:
        daftar_query.extend(dicatat)
    return hasil, status


def _ringkas(hasil: dict) -> str:
    """Satu baris ringkasan hasil tool untuk daftar langkah di layar."""
    if "error" in hasil:
        return str(hasil.get("pesan") or hasil["error"])
    if isinstance(hasil.get("draft_so"), dict):
        return f"draft SO {len(hasil['draft_so'].get('item', []))} item · belum disimpan"
    for kunci in ("data", "produk", "hasil", "komponen_terbesar_perubahannya"):
        if isinstance(hasil.get(kunci), list):
            return f"{len(hasil[kunci])} baris data"
    return "selesai"


def jalankan(pertanyaan: str, kode_pengguna: str = "budi", mode: str = "lokal",
             riwayat: list[dict] | None = None) -> Iterator[dict[str, Any]]:
    """Agent loop: model memilih tool -> kode menjalankan -> hasil kembali ke model -> ulangi sampai ada jawaban."""
    cfg = config.model_untuk(mode)
    u = pengguna.ambil(kode_pengguna)
    mulai = time.perf_counter()
    token_masuk = token_keluar = 0
    tool_dipakai: list[dict] = []
    yield {"tipe": "mulai", "mode": mode, "model": cfg.model, "pengguna": u["nama"]}

    try:
        klien = llm.buat_klien(cfg)
        pesan: list[dict] = [{"role": "system", "content": prompt.system_prompt(kode_pengguna)}]
        # Riwayat percakapan (mis. user memilih salah satu kandidat produk); hanya role & teks yang dikirim.
        pesan += [{"role": m["role"], "content": str(m.get("content") or "")}
                  for m in (riwayat or [])[-6:] if isinstance(m, dict) and m.get("role") in ("user", "assistant")]
        pesan.append({"role": "user", "content": pertanyaan})
        # Model melihat semua tool; izin DICEK OLEH KODE setiap kali tool dijalankan (eksekusi_tool).
        daftar_tool = tools.semua_skema()
        sudah_didorong = False

        for langkah in range(1, config.MAKS_LANGKAH + 1):
            yield {"tipe": "berpikir", "langkah": langkah}
            balasan = llm.panggil(cfg, pesan, daftar_tool, klien)
            token_masuk += balasan.token_masuk
            token_keluar += balasan.token_keluar

            if not balasan.panggilan:
                if not balasan.teks and not sudah_didorong:
                    # model kecil kadang mengembalikan jawaban kosong; minta sekali lagi
                    sudah_didorong = True
                    pesan.append({"role": "user", "content": "(Sistem) Jawabanmu kosong. Pilih tool yang sesuai "
                                  "atau berikan jawaban akhir untuk user sesuai aturan."})
                    continue
                yield {"tipe": "jawaban", "teks": balasan.teks or "Maaf, saya belum bisa menjawab pertanyaan ini."}
                break

            pesan.append(balasan.pesan)
            for p in balasan.panggilan:
                t0 = time.perf_counter()
                daftar_query: list[dict] = []
                hasil, status = eksekusi_tool(p["nama"], p["argumen"], kode_pengguna, daftar_query)
                grafik = hasil.pop("grafik", None) if isinstance(hasil, dict) else None
                ev = {"tipe": "tool", "langkah": langkah, "nama": p["nama"], "argumen": p["argumen"],
                      "status": status, "ringkas": _ringkas(hasil),
                      "durasi_ms": int((time.perf_counter() - t0) * 1000), "hasil": hasil}
                if daftar_query:
                    ev["query"] = daftar_query  # untuk layar saja, tidak dikirim ke model
                tool_dipakai.append({"nama": p["nama"], "status": status})
                yield ev
                if grafik and status == "ok":
                    yield {"tipe": "grafik", "grafik": grafik}
                pesan.append(llm.pesan_hasil_tool(p["id"], hasil))
        else:
            yield {"tipe": "jawaban", "teks": "Maaf, saya belum menemukan jawaban dalam batas langkah yang diizinkan. "
                                              "Coba pertanyaan yang lebih spesifik."}
    except _GAGAL as e:
        yield {"tipe": "error", "pesan": _pesan_error(e, mode, cfg)}

    durasi_ms = int((time.perf_counter() - mulai) * 1000)
    yield {"tipe": "selesai", "durasi_ms": durasi_ms, "token_masuk": token_masuk, "token_keluar": token_keluar}
