"""
RAG (Retrieval-Augmented Generation) untuk dokumen internal.

Alur:
  INGEST : dokumen .md -> dipotong per bagian -> embedding -> disimpan di pgvector
  CARI   : pertanyaan -> embedding -> potongan paling mirip (cosine) -> dikirim ke model sebagai konteks

Setiap potongan membawa judul dan nomor dokumennya, supaya jawaban bisa menyebut sumber.

Tempat penyimpanan: tabel latihan.dokumen_<RAG_KOLEKSI> (nama koleksi kelompok, diisi di .env).
  - ingest memakai DATABASE_URL_PESERTA: role yang hanya bisa membuat tabel di schema "latihan";
  - cari memakai koneksi asisten yang read-only (DATABASE_URL), sama seperti tool lain.

Pemakaian:
  python -m asisten.rag ingest                   # folder dokumen/ -> latihan.dokumen_<RAG_KOLEKSI>
  python -m asisten.rag cari "batas retur roti"  # uji pencarian tanpa model
"""
from __future__ import annotations

import argparse
import re
from pathlib import Path

from openai import OpenAI
from psycopg import sql

from . import config, db

MAKS_KARAKTER = 1200
# Nama koleksi menjadi bagian nama tabel, jadi dibatasi whitelist: huruf kecil, angka, garis bawah.
POLA_KOLEKSI = re.compile(r"[a-z][a-z0-9_]{0,29}")


def nama_tabel() -> str:
    """Nama tabel koleksi kelompok. ValueError bila RAG_KOLEKSI kosong atau tidak valid."""
    nama = config.RAG_KOLEKSI
    if not POLA_KOLEKSI.fullmatch(nama):
        raise ValueError("RAG_KOLEKSI di .env belum diisi atau tidak valid. Gunakan 1-30 karakter: diawali huruf, "
                         "lalu huruf kecil, angka, atau garis bawah (mis. budi_sari).")
    return f"dokumen_{nama}"


# ---------------------------------------------------------------------------
# Memotong dokumen
# ---------------------------------------------------------------------------
def metadata_dokumen(teks: str) -> dict:
    """Baris di bawah judul, mis. "Nomor dokumen: KBJ-PJL-002 · Berlaku sejak: ..." -> {"nomor": "KBJ-PJL-002"}."""
    for baris in teks.splitlines():
        if baris.startswith("## "):
            break
        for bagian in baris.split("·"):
            kunci, _, nilai = bagian.partition(":")
            if kunci.strip().lower() == "nomor dokumen" and nilai.strip():
                return {"nomor": nilai.strip()}
    return {"nomor": ""}


def potong_dokumen(path: Path) -> list[dict]:
    """Potong dokumen Markdown per heading '##'. Bagian yang panjang dipecah per paragraf."""
    teks = Path(path).read_text(encoding="utf-8")
    judul = next((b[2:].strip() for b in teks.splitlines() if b.startswith("# ")), Path(path).stem)
    dokumen = {"sumber": judul, **metadata_dokumen(teks)}   # ikut disimpan di setiap potongan
    hasil = []
    for blok in re.split(r"(?m)^## ", teks)[1:]:
        baris = blok.splitlines()
        bagian, isi = baris[0].strip(), "\n".join(baris[1:]).strip()
        buffer = ""
        for paragraf in re.split(r"\n\s*\n", isi):
            if buffer and len(buffer) + len(paragraf) > MAKS_KARAKTER:
                hasil.append({**dokumen, "bagian": bagian, "isi": buffer.strip()})
                buffer = ""
            buffer += paragraf + "\n\n"
        if buffer.strip():
            hasil.append({**dokumen, "bagian": bagian, "isi": buffer.strip()})
    return hasil


def kumpulkan_potongan(folder: Path) -> list[dict]:
    potongan = []
    for path in sorted(Path(folder).glob("*.md")):
        if path.name.lower() != "readme.md":
            potongan += potong_dokumen(path)
    return potongan


# ---------------------------------------------------------------------------
# Embedding
# ---------------------------------------------------------------------------
def embed(teks: list[str]) -> list[list[float]]:
    """Ubah teks menjadi vektor. Selalu ke server embedding (EMBED_BASE_URL), juga saat model chat memakai cloud."""
    klien = OpenAI(base_url=config.EMBED_BASE_URL, api_key=config.EMBED_API_KEY)
    resp = klien.embeddings.create(model=config.EMBED_MODEL, input=teks)
    return [d.embedding for d in resp.data]


def _teks_embedding(p: dict) -> str:
    """Judul + nomor dokumen + bagian ikut di-embed, agar pertanyaan "KBJ-PJL-002 ..." juga ketemu."""
    judul = f"{p['sumber']} ({p['nomor']})" if p.get("nomor") else p["sumber"]
    return f"{judul} — {p['bagian']}\n{p['isi']}"


def _vektor(v: list[float]) -> str:
    return "[" + ",".join(f"{x:.6f}" for x in v) + "]"


# ---------------------------------------------------------------------------
# Ingest & cari
# ---------------------------------------------------------------------------
def ingest(folder: Path = config.FOLDER_DOKUMEN) -> int:
    """Simpan semua dokumen .md di folder ke koleksi kelompok. Koleksi lama dengan nama yang sama diganti."""
    import psycopg

    tabel = sql.Identifier("latihan", nama_tabel())
    potongan = kumpulkan_potongan(Path(folder))
    if not potongan:
        raise ValueError(f"Tidak ada dokumen .md di {folder}")
    url = config.DATABASE_URL_PESERTA or config.DATABASE_URL_ADMIN
    # Sambung ke database dulu: IP atau password yang salah langsung ketahuan, sebelum embedding.
    with psycopg.connect(url, connect_timeout=10) as conn:
        vektor = embed([_teks_embedding(p) for p in potongan])
        if not config.DATABASE_URL_PESERTA:   # mode laptop sendiri (koneksi admin): pastikan schema ada
            conn.execute("CREATE SCHEMA IF NOT EXISTS latihan")
            conn.execute("GRANT USAGE ON SCHEMA latihan TO erp_ai_readonly")
        conn.execute(sql.SQL("DROP TABLE IF EXISTS {}").format(tabel))
        conn.execute(sql.SQL("""
            CREATE TABLE {} (
                id        SERIAL PRIMARY KEY,
                sumber    TEXT NOT NULL,
                nomor     TEXT NOT NULL DEFAULT '',
                bagian    TEXT NOT NULL,
                isi       TEXT NOT NULL,
                embedding vector({}) NOT NULL
            )""").format(tabel, sql.Literal(len(vektor[0]))))
        for p, v in zip(potongan, vektor):
            conn.execute(
                sql.SQL("INSERT INTO {} (sumber, nomor, bagian, isi, embedding) VALUES (%s, %s, %s, %s, %s::vector)")
                .format(tabel), (p["sumber"], p["nomor"], p["bagian"], p["isi"], _vektor(v)))
        conn.execute(sql.SQL("CREATE INDEX ON {} USING hnsw (embedding vector_cosine_ops)").format(tabel))
        conn.execute(sql.SQL("GRANT SELECT ON {} TO erp_ai_readonly").format(tabel))
    return len(potongan)


def cari(pertanyaan: str, k: int = 4) -> list[dict]:
    """Potongan dokumen paling mirip dengan pertanyaan: [{"sumber", "nomor", "bagian", "isi", "skor"}]."""
    tabel = nama_tabel()   # sudah lolos whitelist, aman disisipkan sebagai nama tabel
    if not db.query("SELECT to_regclass(%(t)s) IS NOT NULL AS ada", {"t": f"latihan.{tabel}"})[0]["ada"]:
        raise ValueError(f"Koleksi dokumen latihan.{tabel} belum dibuat. Jalankan: python -m asisten.rag ingest")
    v = _vektor(embed([pertanyaan])[0])
    return db.query(
        f"""
        SELECT sumber, nomor, bagian, isi, 1 - (embedding <=> %(v)s::vector) AS skor
        FROM latihan."{tabel}"
        ORDER BY embedding <=> %(v)s::vector
        LIMIT %(k)s
        """,
        {"v": v, "k": max(1, min(int(k or 4), 10))},
    )


def main() -> None:
    import sys

    import openai
    import psycopg

    for aliran in (sys.stdout, sys.stderr):   # Windows: keluaran yang di-pipe tidak selalu UTF-8
        if hasattr(aliran, "reconfigure"):
            aliran.reconfigure(encoding="utf-8", errors="replace")

    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("perintah", choices=["ingest", "cari"])
    ap.add_argument("pertanyaan", nargs="*", help="untuk 'cari'")
    args = ap.parse_args()
    try:
        if args.perintah == "ingest":
            n = ingest()
            print(f"{n} potongan dokumen tersimpan di latihan.{nama_tabel()} (model embedding: {config.EMBED_MODEL})")
        else:
            if not args.pertanyaan:
                raise SystemExit('Contoh: python -m asisten.rag cari "batas waktu retur roti"')
            for h in cari(" ".join(args.pertanyaan)):
                nomor = f" ({h['nomor']})" if h.get("nomor") else ""
                print(f"[{h['skor']:.2f}] {h['sumber']}{nomor} › {h['bagian']}\n"
                      f"    {h['isi'][:160].replace(chr(10), ' ')}…")
    except ValueError as e:
        raise SystemExit(str(e)) from None
    except psycopg.Error as e:
        raise SystemExit(f"Database menolak atau tidak dapat dihubungi: {str(e).splitlines()[0]}\n"
                         "Periksa DATABASE_URL_PESERTA dan DATABASE_URL di .env.") from None
    except openai.APIError as e:
        raise SystemExit(f"Server embedding bermasalah di {config.EMBED_BASE_URL}: {e}\n"
                         "Periksa EMBED_BASE_URL di .env.") from None


if __name__ == "__main__":
    main()
