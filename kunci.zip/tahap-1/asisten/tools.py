"""
Tools yang boleh dipakai asisten AI.

Pola setiap tool:
  1. Deskripsi + skema parameter (JSON Schema) -> dibaca model untuk memilih tool.
  2. Izin yang dibutuhkan -> dicek oleh kode sebelum tool dijalankan.
  3. Fungsi Python yang menjalankan query BERPARAMETER ke view schema "ai".
  4. Hasil berisi angka yang sudah dihitung & diformat oleh kode (field *_fmt),
     sehingga model cukup menjelaskan, bukan menghitung.
  5. Field "grafik" (opsional) dikirim ke layar, tidak dikirim ke model.

Yang sudah ada dari template: registry, dekorator @tool, pencarian nama produk yang
toleran ejaan, dan SATU tool contoh (cari_produk). Tool lain dibangun per tahap.

View yang boleh dibaca (schema "ai"):
  ai.v_info         nama_perusahaan, tanggal_posisi
  ai.v_produk       id, kode, nama, kategori, satuan, harga_jual
  ai.v_customer     id, kode, nama, kota, segmen, termin_hari
  ai.v_penjualan    tanggal, bulan, nomor_faktur, customer_id, customer, kota, segmen,
                    produk_id, kode_produk, produk, kategori, qty, harga, diskon_persen, nilai
  ai.v_hpp_bulanan  bulan, produk_id, kode_produk, produk, unit_diproduksi, bahan_baku_per_unit,
                    tenaga_kerja_per_unit, overhead_per_unit, hpp_per_unit
  ai.v_hpp_komponen bulan, produk_id, produk, bahan_id, bahan, satuan, qty_per_unit, harga_bahan, biaya_per_unit
  ai.v_harga_bahan  bulan, bahan_id, kode, bahan, satuan, harga
  ai.v_piutang      faktur_id, nomor_faktur, tanggal, jatuh_tempo, customer_id, customer, kota, segmen,
                    total, terbayar, sisa, hari_lewat_jatuh_tempo
  ai.v_stok         produk_id, kode_produk, produk, gudang, qty, stok_minimum, di_bawah_minimum
Kolom "bulan" selalu tanggal 1 bulan itu (mis. 2026-10-01).
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any, Callable

from . import db
from . import format as fmt


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------
@dataclass
class Tool:
    nama: str
    deskripsi: str
    parameter: dict
    izin: str
    fungsi: Callable[..., dict]

    def skema(self) -> dict:
        """Format definisi tool untuk API Chat Completions (OpenAI-compatible)."""
        return {
            "type": "function",
            "function": {"name": self.nama, "description": self.deskripsi, "parameters": self.parameter},
        }


REGISTRY: dict[str, Tool] = {}


def tool(nama: str, deskripsi: str, parameter: dict, izin: str):
    """Dekorator untuk mendaftarkan fungsi sebagai tool."""
    def daftar(fungsi: Callable[..., dict]) -> Callable[..., dict]:
        REGISTRY[nama] = Tool(nama, deskripsi, parameter, izin, fungsi)
        return fungsi
    return daftar


def semua_skema() -> list[dict]:
    return [t.skema() for t in REGISTRY.values()]


def skema_untuk(izin_user: list[str]) -> list[dict]:
    """Alternatif: hanya tool yang diizinkan untuk user ini yang diperlihatkan ke model."""
    return [t.skema() for t in REGISTRY.values() if t.izin in izin_user]


# ---------------------------------------------------------------------------
# Merapikan argumen dari model (model kecil kadang mengirim '3' untuk 3, atau '2%' untuk 2)
# ---------------------------------------------------------------------------
def _pilih_enum(nilai: Any, pilihan: list) -> Any:
    """'Segmen' -> 'segmen', 'surabaya' -> 'Gudang Surabaya'. None bila tidak ada satu pilihan yang cocok."""
    rendah = str(nilai).strip().lower()
    cocok = [p for p in pilihan if str(p).lower() == rendah] or [p for p in pilihan if rendah and rendah in str(p).lower()]
    return cocok[0] if len(cocok) == 1 else None


def rapikan_argumen(skema: dict, argumen: dict) -> dict:
    """
    Buang argumen yang tidak ada di skema dan ubah tipe dasar sesuai skema.
    Panggil ini sebelum menjalankan fungsi tool: fungsi(**rapikan_argumen(tool.parameter, argumen)).
    Array dan object dibiarkan apa adanya; tool yang merapikan isinya.
    """
    props = skema.get("properties", {})
    hasil = {}
    for k, v in (argumen or {}).items():
        if k not in props or v is None:
            continue
        tipe = props[k].get("type")
        try:
            if tipe == "integer":
                v = int(float(v))
            elif tipe == "number":
                v = float(v.replace("%", "").replace(",", ".").strip()) if isinstance(v, str) else float(v)
            elif tipe == "string":
                v = str(v)
        except (TypeError, ValueError):
            continue
        if "enum" in props[k] and v not in props[k]["enum"]:
            v = _pilih_enum(v, props[k]["enum"])
            if v is None:
                continue
        hasil[k] = v
    return hasil


# ---------------------------------------------------------------------------
# Pencarian nama produk / bahan yang toleran ejaan
# ---------------------------------------------------------------------------
SINONIM = {"coklat": "cokelat", "choco": "cokelat", "chocolate": "cokelat", "tawar": "tawar",
           "biscuit": "biskuit", "biskut": "biskuit", "kripik": "keripik", "kopsus": "kopi susu"}
SINONIM_BAHAN = {"cokelat": "kakao", "coklat": "kakao", "cocoa": "kakao", "terigu": "tepung", "sawit": "minyak"}


def _kata(teks: str, sinonim: dict[str, str]) -> list[str]:
    teks = teks.lower()
    for a, b in sinonim.items():
        teks = re.sub(rf"\b{a}\b", b, teks)
    return [k for k in re.split(r"[^a-z0-9]+", teks) if len(k) > 1]


def _cocokkan(teks: str, kandidat: list[dict], sinonim: dict[str, str]) -> list[dict]:
    """Pilih kandidat yang paling banyak cocok kata-katanya dengan teks."""
    kata = _kata(teks, sinonim)
    if not kata:
        return []
    skor = []
    for k in kandidat:
        nama = " ".join(_kata(k["nama"], {})) + " " + k.get("kode", "").lower()
        s = sum(1 for w in kata if w in nama)
        if s:
            skor.append((s, k))
    if not skor:
        return []
    terbaik = max(s for s, _ in skor)
    return [k for s, k in skor if s == terbaik]


def _resolve_produk(teks: str) -> tuple[dict | None, dict | None]:
    """Kembalikan (produk, error). Error berisi saran bila tidak ketemu / ambigu."""
    semua = db.query("SELECT id, kode, nama, kategori, satuan, harga_jual FROM ai.v_produk ORDER BY nama")
    cocok = _cocokkan(teks, semua, SINONIM)
    if len(cocok) == 1:
        return cocok[0], None
    if not cocok:
        return None, {"error": f"Produk '{teks}' tidak ditemukan.",
                      "produk_tersedia": [p["nama"] for p in semua]}
    return None, {"error": f"Ada {len(cocok)} produk yang cocok dengan '{teks}'. Tanyakan ke user produk yang dimaksud.",
                  "kandidat": [p["nama"] for p in cocok]}


def _rentang_bulan(bulan_terakhir: int) -> tuple:
    bulan_terakhir = max(1, min(int(bulan_terakhir or 6), 18))
    akhir = db.info()["bulan_terakhir"]
    awal = fmt.tambah_bulan(akhir, -(bulan_terakhir - 1))
    return awal, akhir, bulan_terakhir


def _periode(awal, akhir) -> str:
    return fmt.bulan(akhir) if awal == akhir else f"{fmt.bulan(awal)} s.d. {fmt.bulan(akhir)}"


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------
# Tool contoh dari template. Tiru polanya untuk tool lain.
@tool(
    nama="cari_produk",
    deskripsi="Mencari produk berdasarkan nama atau kode. Mengembalikan kode, nama, kategori, dan harga jual.",
    parameter={
        "type": "object",
        "properties": {
            "kata_kunci": {"type": "string", "description": "Nama atau kode produk, mis. 'roti cokelat'. Kosongkan untuk semua produk."},
        },
        "required": [],
    },
    izin="produk",
)
def cari_produk(kata_kunci: str = "") -> dict:
    semua = db.query("SELECT kode, nama, kategori, satuan, harga_jual FROM ai.v_produk ORDER BY kategori, nama")
    hasil = _cocokkan(kata_kunci, semua, SINONIM) if kata_kunci.strip() else semua
    for p in hasil:
        p["harga_jual_fmt"] = fmt.rupiah(p["harga_jual"])
    return {"jumlah": len(hasil), "produk": hasil}


@tool(
    nama="tren_penjualan",
    deskripsi=("Data penjualan per bulan (qty dan nilai rupiah) untuk satu produk atau seluruh produk, "
               "beserta perubahan dari bulan pertama ke bulan terakhir. Bisa dirinci per segmen customer atau per kota."),
    parameter={
        "type": "object",
        "properties": {
            "produk": {"type": "string", "description": "Nama produk, mis. 'Biskuit Kelapa'. Kosongkan untuk total semua produk."},
            "bulan_terakhir": {"type": "integer", "description": "Jumlah bulan ke belakang (1-18). Default 6."},
            "rincian": {"type": "string", "enum": ["total", "segmen", "kota"],
                        "description": "'segmen' atau 'kota' untuk melihat asal kenaikan/penurunan. Default 'total'."},
        },
        "required": [],
    },
    izin="penjualan",
)
def tren_penjualan(produk: str = "", bulan_terakhir: int = 6, rincian: str = "total") -> dict:
    awal, akhir, n = _rentang_bulan(bulan_terakhir)
    produk_id, nama = None, "Semua produk"
    if produk and produk.strip().lower() not in ("semua", "semua produk", "total", "all"):
        p, err = _resolve_produk(produk)
        if err:
            return err
        produk_id, nama = p["id"], p["nama"]

    baris = db.query(
        """
        SELECT bulan, sum(qty) AS qty, sum(nilai) AS nilai
        FROM ai.v_penjualan
        WHERE bulan BETWEEN %(awal)s AND %(akhir)s
          AND (%(pid)s::int IS NULL OR produk_id = %(pid)s::int)
        GROUP BY bulan ORDER BY bulan
        """,
        {"awal": awal, "akhir": akhir, "pid": produk_id},
    )
    if not baris:
        return {"produk": nama, "periode": _periode(awal, akhir), "data": [],
                "catatan": "Tidak ada data penjualan pada periode ini."}

    data = [{"bulan": fmt.bulan(b["bulan"]), "qty": b["qty"], "nilai": round(b["nilai"]),
             "nilai_fmt": fmt.rupiah(b["nilai"])} for b in baris]
    pertama, terakhir = baris[0], baris[-1]
    tertinggi = max(baris, key=lambda b: b["qty"])
    hasil: dict[str, Any] = {
        "produk": nama,
        "periode": _periode(awal, akhir),
        "data": data,
        "ringkasan": {
            "perubahan_qty_persen": fmt.persen(fmt.ubah_persen(pertama["qty"], terakhir["qty"])),
            "perubahan_nilai_persen": fmt.persen(fmt.ubah_persen(pertama["nilai"], terakhir["nilai"])),
            "dibandingkan": f"{fmt.bulan(pertama['bulan'])} vs {fmt.bulan(terakhir['bulan'])}",
            "total_nilai_periode_fmt": fmt.rupiah(sum(b["nilai"] for b in baris)),
            "bulan_qty_tertinggi": fmt.bulan(tertinggi["bulan"]),
        },
    }
    seri = [{"nama": "Qty (unit)", "data": [b["qty"] for b in baris]}]

    if rincian in ("segmen", "kota"):
        kolom = rincian  # nilai sudah dibatasi oleh enum; tetap dipetakan eksplisit
        kolom_sql = {"segmen": "segmen", "kota": "kota"}[kolom]
        per_dim = db.query(
            f"""
            SELECT {kolom_sql} AS dimensi, bulan, sum(qty) AS qty
            FROM ai.v_penjualan
            WHERE bulan BETWEEN %(awal)s AND %(akhir)s
              AND (%(pid)s::int IS NULL OR produk_id = %(pid)s::int)
            GROUP BY 1, 2 ORDER BY 1, 2
            """,
            {"awal": awal, "akhir": akhir, "pid": produk_id},
        )
        tabel: dict[str, dict] = {}
        for r in per_dim:
            tabel.setdefault(r["dimensi"], {})[r["bulan"]] = r["qty"]
        rinci = []
        for dim, nilai in tabel.items():
            q_awal, q_akhir = nilai.get(pertama["bulan"], 0), nilai.get(terakhir["bulan"], 0)
            rinci.append({kolom: dim, f"qty_{fmt.bulan_pendek(pertama['bulan'])}": q_awal,
                          f"qty_{fmt.bulan_pendek(terakhir['bulan'])}": q_akhir,
                          "selisih_qty": q_akhir - q_awal,
                          "perubahan_persen": fmt.persen(fmt.ubah_persen(q_awal, q_akhir))})
        rinci.sort(key=lambda r: -abs(r["selisih_qty"]))
        hasil["rincian_per_" + kolom] = rinci
        seri = [{"nama": dim, "data": [tabel[dim].get(b["bulan"], 0) for b in baris]}
                for dim in sorted(tabel, key=lambda d: -sum(tabel[d].values()))[:6]]

    hasil["grafik"] = {
        "tipe": "line",
        "judul": f"Penjualan {nama} (unit)" + ("" if rincian == "total" else f" per {rincian}"),
        "label": [fmt.bulan_pendek(b["bulan"]) for b in baris],
        "seri": seri,
    }
    return hasil


@tool(
    nama="penjualan_teratas",
    deskripsi=("Peringkat NILAI PENJUALAN (omzet) atau qty terjual teratas berdasarkan produk, customer, kota, segmen, "
               "atau kategori dalam beberapa bulan terakhir. Hanya untuk data penjualan, BUKAN untuk piutang atau tagihan."),
    parameter={
        "type": "object",
        "properties": {
            "dimensi": {"type": "string", "enum": ["produk", "customer", "kota", "segmen", "kategori"],
                        "description": "Dasar peringkat. Default 'produk'."},
            "bulan_terakhir": {"type": "integer", "description": "Jumlah bulan ke belakang (1-18). Default 3."},
            "urut": {"type": "string", "enum": ["nilai", "qty"], "description": "Urutkan berdasarkan nilai rupiah atau qty. Default 'nilai'."},
            "jumlah": {"type": "integer", "description": "Jumlah baris (1-20). Default 5."},
        },
        "required": [],
    },
    izin="penjualan",
)
def penjualan_teratas(dimensi: str = "produk", bulan_terakhir: int = 3, urut: str = "nilai", jumlah: int = 5) -> dict:
    kolom = {"produk": "produk", "customer": "customer", "kota": "kota", "segmen": "segmen", "kategori": "kategori"}.get(dimensi)
    if not kolom:
        return {"error": f"Dimensi '{dimensi}' tidak dikenal. Pilihan: produk, customer, kota, segmen, kategori."}
    urut_sql = "qty" if urut == "qty" else "nilai"
    jumlah = max(1, min(int(jumlah or 5), 20))
    awal, akhir, _ = _rentang_bulan(bulan_terakhir)
    baris = db.query(
        f"""
        SELECT {kolom} AS nama, sum(qty) AS qty, sum(nilai) AS nilai
        FROM ai.v_penjualan
        WHERE bulan BETWEEN %(awal)s AND %(akhir)s
        GROUP BY 1 ORDER BY {urut_sql} DESC LIMIT %(n)s
        """,
        {"awal": awal, "akhir": akhir, "n": jumlah},
    )
    total = db.query("SELECT sum(nilai) AS nilai FROM ai.v_penjualan WHERE bulan BETWEEN %(awal)s AND %(akhir)s",
                     {"awal": awal, "akhir": akhir})[0]["nilai"] or 0
    for i, b in enumerate(baris, 1):
        b["peringkat"] = i
        b["nilai"] = round(b["nilai"])
        b["nilai_fmt"] = fmt.rupiah(b["nilai"])
        b["porsi_dari_total"] = fmt.persen(b["nilai"] / total * 100 if total else None, tanda=False)
    return {
        "periode": _periode(awal, akhir),
        "dimensi": dimensi,
        "urut": urut_sql,
        "data": baris,
        "total_penjualan_periode_fmt": fmt.rupiah(total),
        "grafik": {
            "tipe": "bar",
            "judul": f"{jumlah} {dimensi} teratas ({'qty' if urut_sql == 'qty' else 'Rp juta'})",
            "label": [b["nama"] for b in baris],
            "seri": [{"nama": "Qty" if urut_sql == "qty" else "Nilai (Rp juta)",
                      "data": [b["qty"] if urut_sql == "qty" else round(b["nilai"] / 1e6, 1) for b in baris]}],
            "horizontal": True,
        },
    }


# Tool tambahan (fitur pilihan di Tahap 5) dimuat otomatis dari asisten/tools_tambahan.py.
from . import tools_tambahan  # noqa: F401,E402
